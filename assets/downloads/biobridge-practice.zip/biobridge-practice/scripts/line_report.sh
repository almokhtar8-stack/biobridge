#!/bin/bash
# Report how many lines each .tsv file in a folder has.
# Usage: bash line_report.sh FOLDER
for f in "$1"/*.tsv
do
  echo "$f: $(wc -l < "$f") lines"
done
