#!/bin/bash
# Count the sequences in a FASTA file.
# Usage: ./count_seqs.sh FILE
file=$1
n=$(grep -c ">" "$file")
echo "$file contains $n sequences"
